#!/usr/bin/env bash
set -euo pipefail

CLUSTER_NAME="${CLUSTER_NAME:-deckhand-dev}"
KIND_CONFIG="${KIND_CONFIG:-kind-config.yaml}"
TEKTON_VERSION_URL="${TEKTON_VERSION_URL:-https://storage.googleapis.com/tekton-releases/pipeline/latest/release.yaml}"
NS_APP="${NS_APP:-deckhand-lab}"

cat > "${KIND_CONFIG}" <<'EOF'
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
name: deckhand-dev
nodes:
  - role: control-plane
  - role: worker
  - role: worker
EOF

echo "[1/6] Creating kind cluster: ${CLUSTER_NAME}"
kind create cluster --name "${CLUSTER_NAME}" --config "${KIND_CONFIG}"

echo "[2/6] Creating app namespace"
kubectl create namespace "${NS_APP}" || true

echo "[3/6] Installing Tekton Pipelines"
kubectl apply -f "${TEKTON_VERSION_URL}"

echo "[4/6] Waiting for Tekton controller rollout"
kubectl -n tekton-pipelines rollout status deploy/tekton-pipelines-controller --timeout=180s
kubectl -n tekton-pipelines rollout status deploy/tekton-pipelines-webhook --timeout=180s

echo "[5/6] Applying sample manifests"
kubectl apply -n "${NS_APP}" -f manifests/tekton-task-hello.yaml
kubectl apply -n "${NS_APP}" -f manifests/tekton-pipeline-hello.yaml
kubectl apply -n "${NS_APP}" -f manifests/tekton-pipelinerun-success.yaml
kubectl apply -n "${NS_APP}" -f manifests/tekton-pipelinerun-fail.yaml || true
kubectl apply -n "${NS_APP}" -f manifests/sample-crashloop-pod.yaml || true
kubectl apply -n "${NS_APP}" -f manifests/sample-pending-pod.yaml || true

echo "[6/6] Done"
kubectl config current-context
kubectl get pods -A
kubectl get pipelineruns -n "${NS_APP}" || true
