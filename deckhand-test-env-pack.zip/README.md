# Deckhand Local Test Environment Pack

This pack gives Codex a practical local test ladder for Deckhand:

1. Fast lane: `kind` + Tekton Pipelines
2. Truth lane: OpenShift Local + OpenShift Pipelines

## Included
- docs/test-strategy.md
- docs/test-matrix.md
- docs/openshift-local-notes.md
- examples/CODEX-TEST-ENV-PROMPT.txt
- scripts/setup-kind-tekton.sh
- scripts/reset-kind-tekton.sh
- manifests/tekton-task-hello.yaml
- manifests/tekton-pipeline-hello.yaml
- manifests/tekton-pipelinerun-success.yaml
- manifests/tekton-pipelinerun-fail.yaml
- manifests/sample-crashloop-pod.yaml
- manifests/sample-pending-pod.yaml

## Recommended flow
- Use kind + Tekton for fast Deckhand iteration
- Use OpenShift Local + OpenShift Pipelines for OpenShift-specific validation
